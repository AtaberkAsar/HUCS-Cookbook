public class Main {
    public static void main(String[] args) {
        Bejeweled bejeweledGame = new Bejeweled(args[0], args[1], "leaderboard.txt");
    }
}
