import java.util.List;

public interface JewelSubclass {
    List<Integer[][]> getChecks();
}
