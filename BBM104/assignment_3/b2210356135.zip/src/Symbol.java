public abstract class Symbol extends Jewel implements JewelSubclass{

}
